﻿using System.Web.UI;

namespace Request_Portal.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}