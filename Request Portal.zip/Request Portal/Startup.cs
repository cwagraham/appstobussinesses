﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Request_Portal.Startup))]
namespace Request_Portal
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
